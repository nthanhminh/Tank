#pragma once
#ifndef HOME_H
#define HOME_H
#include "CommonFunc.h"
#include "BaseObject.h"
#include <iostream>
class Home :public baseObject {
private:
	std::string path;
public:
};
#endif